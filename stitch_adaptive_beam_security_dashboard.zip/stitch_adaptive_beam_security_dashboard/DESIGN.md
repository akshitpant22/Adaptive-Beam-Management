---
name: Signal Intelligence
colors:
  surface: '#0f1418'
  surface-dim: '#0f1418'
  surface-bright: '#343a3e'
  surface-container-lowest: '#0a0f12'
  surface-container-low: '#171c20'
  surface-container: '#1b2024'
  surface-container-high: '#252b2e'
  surface-container-highest: '#303539'
  on-surface: '#dee3e8'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dee3e8'
  inverse-on-surface: '#2c3135'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#ffc176'
  on-tertiary: '#472a00'
  tertiary-container: '#f1a02b'
  on-tertiary-container: '#613b00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb960'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0f1418'
  on-background: '#dee3e8'
  surface-variant: '#303539'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
  metric-sm:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  panel-width: 320px
  gutter: 16px
---

## Brand & Style

The design system is engineered for high-stakes technical environments requiring precision and real-time situational awareness. The aesthetic is a fusion of **Corporate Modern** and **Technological Minimalism**, optimized for dark-room monitoring stations where visual fatigue must be minimized.

The interface prioritizes information density and clarity. It utilizes a deep-space color palette to create a low-luminance background, allowing high-contrast cyan data points and status indicators to command immediate attention. The overall mood is authoritative, clinical, and predictive.

## Colors

The palette is anchored by a dark navy foundation, providing a stable, high-contrast environment for technical visualization. 

- **Primary (Cyan):** Used exclusively for active states, interactive UI elements, and primary signal paths.
- **Secondary (Purple):** Reserved for secrecy metrics and cryptographic overhead data.
- **Status Tiers:** Success (Green), Threat (Red), and Warning (Yellow) follow standard industrial conventions. Noise/GPS data uses Orange to distinguish environmental factors from security threats.
- **Map Canvas:** City blocks and terrain utilize a specialized sand-colored background to provide a clear visual break between the dashboard UI and the simulation environment.

## Typography

This design system utilizes a dual-font approach to separate narrative information from technical data. 

**Inter** provides a highly legible, neutral foundation for all interface labels, descriptions, and structural headers. **JetBrains Mono** is employed for all variable data, telemetry, and metrics to ensure character alignment and a "code-driven" aesthetic. All metric labels should be rendered in `label-caps` to emphasize their status as fixed data identifiers.

## Layout & Spacing

The layout uses a **fixed-sidebar fluid-content** model. Critical telemetry and control panels are housed in fixed 320px sidebars (left and right), while the central simulation canvas expands to fill the remaining viewport.

A rigorous 4px grid governs all spacing. Vertical rhythm is maintained through 16px increments between metric cards. Data-heavy side panels should utilize a "compact" density setting, reducing vertical padding to 8px to maximize information visibility without requiring excessive scrolling.

## Elevation & Depth

Depth is conveyed through **Tonal Layering** rather than traditional shadows.
- **Level 0 (Background):** #0f172a (Deepest)
- **Level 1 (Side Panels/Headers):** #1a1a2e 
- **Level 2 (Cards/Containers):** #1e293b
- **Level 3 (Popovers/Tooltips):** #334155 with a subtle 1px border of #38bdf8 at 20% opacity.

The simulation canvas is treated as a separate physical layer, visually recessed behind the UI chrome using inner shadows to imply a "window" into the simulation.

## Shapes

The shape language is strictly geometric. Standard UI elements (buttons, inputs, cards) use a 4px corner radius (`rounded-sm`). This maintains a technical, "instrument-panel" feel while avoiding the harshness of 90-degree angles. Interactive nodes on the map canvas may use 100% rounding (circles) to differentiate entities from interface containers.

## Components

### Metric Cards
Cards consist of a `label-caps` top-aligned header and a `metric-lg` value. The value color must change based on status (e.g., Green for secure, Red for threat). Use a subtle 2px left-border accent of the same status color to enhance peripheral scannability.

### Action Buttons
Primary actions use a 1px Cyan border with transparent background. On hover, the button fills with Cyan (#38bdf8) and the text inverts to the background color (#0f172a). 

### Status Indicators
Small circular badges or "pills." For critical alerts, the indicator should include a subtle "pulse" animation. Background colors should use a 20% opacity version of the status color with a 100% opacity text/icon overlay.

### Side Panels
Sidebars feature a "frosted" separator line (1px width, #334155). Scrollbars are custom-styled: 4px width, track-less, with a Cyan thumb that only appears on hover to minimize visual noise during active monitoring.

### Map Controls
Floating UI elements over the map canvas should have a high-blur backdrop filter (10px) and a semi-transparent dark fill to maintain legibility against the sand-colored terrain.